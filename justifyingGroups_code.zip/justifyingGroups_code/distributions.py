import random
import math

class VotesGenerator(object):
  def generate(self, candidates):
    pass
  def description(self):
    pass

class ParameterizedGenerator(VotesGenerator):
  def parameters(self):
    pass

class EqualChooseDistribution(ParameterizedGenerator):
  def __init__(self, approvalProbability):
    self._approvalProbability = approvalProbability

  def generate(self, candidates, votersnr):
    votes = {}
    for i in range(votersnr):
      vote = []
      for c in candidates:
        if random.random() < self._approvalProbability:
          vote.append(c)
      votes[i]=vote
    return votes
  
  def description(self):
    return "Impartial, probability: {}".format(self._approvalProbability)
  
  def parameters(self):
    return (self._approvalRadius,)


class OneDDistribution(ParameterizedGenerator):
  def __init__(self, approvalRadius):
    self._approvalRadius = approvalRadius

  def generate(self, candidates, votersnr):
    votersPositions = []
    candidatesPositions = []
    for i in range(votersnr):
      votersPositions.append(random.uniform(0,1))
    for i in range(len(candidates)):
      candidatesPositions.append(random.uniform(0,1))
    votes = {}
    for i in range(votersnr):
      vote = []
      maxApproved = votersPositions[i]+self._approvalRadius
      minApproved = votersPositions[i]-self._approvalRadius
      for c in range(len(candidates)):
        if candidatesPositions[c] <= maxApproved and candidatesPositions[c] >= minApproved:
          vote.append(c)
      votes[i]=vote
    return votes

  def description(self):
    return "1D, radius: {}".format(self._approvalRadius)

  def parameters(self):
    return (self._approvalRadius,)


class TwoDDistribution(ParameterizedGenerator):
  def __init__(self, approvalRadius):
    self._approvalRadius = approvalRadius

  def generate(self, candidates, votersnr):

    votersPositions = []
    candidatesPositions = []
    for i in range(votersnr):
      votersPositions.append((random.uniform(0,1), random.uniform(0,1)))
    for i in range(len(candidates)):
      candidatesPositions.append((random.uniform(0,1), random.uniform(0,1)))
    votes = {}
    for i in range(votersnr):
      vote = []
      vx = votersPositions[i][0]
      vy = votersPositions[i][1]
      for c in range(len(candidates)):
        cx = candidatesPositions[c][0]
        cy = candidatesPositions[c][1]
        if math.hypot(vx - cx, vy - cy) <= self._approvalRadius:
          vote.append(c)
      votes[i]=vote
    return votes

  def description(self):
    return "2D, radius: {}".format(self._approvalRadius)

  def parameters(self):
    return (self._approvalRadius,)
    
