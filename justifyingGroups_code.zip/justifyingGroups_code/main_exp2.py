from distributions import EqualChooseDistribution,OneDDistribution,TwoDDistribution
import random
import baseProgram
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import math
from tqdm import tqdm

#Function maxSupport
def maxSupport(V,m):
    #compute the number of supporters for all candidates
    counts = [len([v for v in V if c in V[v]]) for c in range(m)]
    return max(counts)

#returns most popular candidate
def mostPopular(V,m):
    #compute the number of supporters for all candidates
    counts = [len([v for v in V if c in V[v]]) for c in range(m)]
    max_elements = [i for i, x in enumerate(counts) if x == max(counts)]
    return random.choice(max_elements)


#Function checks for JR when size o
def isJR(V,W,m,k,n):
    #remove all voters which already approve one candidate in W
    V_new = dict((v,V[v]) for v in V if set(V[v]).intersection(set(W)) == set())
    
    if len(V_new) == 0:
        return True
    
    if maxSupport(V_new,m) >= float(n)/float(k):
        return False
    return True

def GreedyCC(V,m,k):
    W = []
    n = len(V)
    while(isJR(V,W,m,k,n)==False):
        c = mostPopular(V,m)
        W = W + [c]
        #remove all candidates that approve c
        V = dict((v,V[v]) for v in V if c not in V[v])
    return W

def GreedyCandidate(V,m,k):
    W = []
    C = range(m)
    n = len(V)
    ell = max([math.ceil(float(n)/float(k)) - 1,0])
    supp_dict = dict((c,[i for i in V if c in V[i]]) for c in C)
    while max([len(supp_dict[c]) for c in C]) > ell:
        util_dict = dict((c,sum([max([len(supp_dict[cp]) - ell,0]) - max([len(set(supp_dict[cp]) - set(supp_dict[c])) - ell,0]) for cp in C])) for c in C)
        c_max = max(util_dict, key=util_dict.get)
        W = W + [c_max]
        for c in list(set(C)-set([c_max])):
            supp_dict[c] = list(set(supp_dict[c]) - set(supp_dict[c_max]))
        supp_dict[c_max] = []
        C = list(set(C) - set([c_max]))
    return W

def getMinimumJustifyingGroup(candidates, voters, committeeSize):
    votersCount = len(voters)
    candidatesCount = len(candidates)
    _, jrcSize = baseProgram.compute(candidates, voters, 0,votersCount*candidatesCount, 0, votersCount, committeeSize, baseProgram.CORE_MIN, True)
    return jrcSize
    
    
########## Run experiments for all three models ################
m = 100
k = 10
n = 100
repeat = 200

model_list1 = [('IC',p) for p in [i/100 for i in range(0,100,2)]]
model_list2 = [('1D',p) for p in [i/100 for i in range(0,100,2)]]
model_list3 = [('2D',p) for p in [i/100 for i in range(0,120,2)]]

meta_list = [model_list1, model_list2, model_list3]

for model_list in meta_list:
    random.seed(200)
    exp1_data = pd.DataFrame(columns=['n','p','k','z','avApp','minjr','greedycc','greedyCandidate','fractionCC','fractionCandidate'],dtype=float)
    exp1_data = exp1_data.set_index(['n','p','k','z'])

    for model in tqdm(model_list):
        for z in range(repeat):
            p = model[1]
            #Step1 - create elections
            if model[0] == 'IC':
                election = EqualChooseDistribution(p).generate(range(m),n)
            if model[0] == '1D':
                election = OneDDistribution(p).generate(range(m),n)
            if model[0] == '2D':
                election = TwoDDistribution(p).generate(range(m),n)


            #Step2.1 - Compute GreedyCandidate
            Wp = GreedyCandidate(election,m,k)
            exp1_data.at[(n,p,k,z),'greedyCandidate'] = float(len(Wp))

            #Step2.2 - Compute GreedyCC
            W = GreedyCC(election,m,k)
            exp1_data.at[(n,p,k,z),'greedycc'] = float(len(W))
            exp1_data.at[(n,p,k,z),'avA'] = np.mean([len(election[v]) for v in range(n)])

            #Step3 - Get minimum JR size
            minjrsize = getMinimumJustifyingGroup(range(m),election,k)
            exp1_data.at[(n,p,k,z),'minjr'] = float(minjrsize)
            exp1_data.at[(n,p,k,z),'fractionCC'] = int(float(minjrsize) == float(len(W)))
            exp1_data.at[(n,p,k,z),'fractionCandidate'] = int(float(minjrsize) == float(len(Wp)))

    exp1_data = exp1_data.reset_index()
    
    exp1_data.to_csv('experiment2_raw-data_'  + model[0] + '.csv')



            
########### Plot results for the IC Model ######################
pure1 = 'experiment2_raw-data_IC.csv'
pure1 = pd.read_csv(pure1,index_col=0)
agg1 = pure1.groupby('p')[['avA','greedycc','greedyCandidate','minjr']].mean()
std1 = pure1.groupby('p')[['greedycc','greedyCandidate','minjr']].std()

pure2 = 'experiment2_raw-data_1D.csv'
pure2 = pd.read_csv(pure2,index_col=0)
agg2 = pure2.groupby('p')[['avA','greedycc','greedyCandidate','minjr']].mean()
std2 = pure2.groupby('p')[['greedycc','greedyCandidate','minjr']].std()

pure3 = 'experiment2_raw-data_2D.csv'
pure3 = pd.read_csv(pure3,index_col=0)
agg3 = pure3.groupby('p')[['avA','greedycc','greedyCandidate','minjr']].mean()
std3 = pure3.groupby('p')[['greedycc','greedyCandidate','minjr']].std()

agg = [agg1,agg2,agg3]
std_all = [std1,std2,std3]
models = ['IC','1D','2D']

    
for i in range(3):
    data = agg[i]
    stdi = std_all[i]
    fig = plt.figure(figsize=(12,8), dpi= 300)
    ax = fig.add_subplot(111)
    ax.set_ylim([0,6])

    cols = ['greedycc','greedyCandidate','minjr']
    patterns = dict({'greedycc':'dashed','greedyCandidate':'dotted','minjr':'solid'})
    names = dict({'greedycc':'GreedyCC','greedyCandidate':'GreedyCandidate','minjr':'Minimum'})

    for col in cols:
        plt.plot(data['avA'],data[col],linestyle = patterns[col],linewidth=4.0)

    ax.legend(names.values(),fontsize=28)
    ax.yaxis.label.set_size(28)
    ax.xaxis.label.set_size(28)
    ax.tick_params(axis='both', which='major', labelsize=24)
    plt.ylabel(r'average size of justifying group',labelpad=30)
    plt.xlabel(r'average number of approvals',labelpad=30)

    plt.savefig('exp2_plot_'+ models[i]+'.png',bbox_inches='tight')
    plt.show()
