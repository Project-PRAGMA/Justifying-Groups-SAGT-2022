from distributions import EqualChooseDistribution,OneDDistribution,TwoDDistribution
import random
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from tqdm import tqdm


#Function maxSupport
def maxSupport(V,m):
    #compute the number of supporters for all candidates
    counts = [len([v for v in V if c in V[v]]) for c in range(m)]
    #return maximum support of a candidate
    return max(counts)


#Function checks for JR when size o
def isJR(V,W,m,k):
    n = len(V)
    #remove all voters which already approve one candidate in W
    V_new = dict((v,V[v]) for v in V if set(V[v]).intersection(set(W)) == set())
    
    if len(V_new) == 0:
        return True
    
    #among all unrepresented voters compute one with maximum support and check whether the corresponding group is large enough
    if maxSupport(V_new,m) >= float(n)/float(k):
        return False
    return True
    
    
########## Run experiments for all three models ################

model_list = ['IC','1D','2D']
n = 5000
m = 100
k = 10
R = [1,2,3,4]
repeat = 1000

for model in model_list:
    random.seed(200)
    if model == 'IC':
        P = [i/100 for i in range(0,100,2)]
    if model == '1D':
        P = [i/100 for i in range(0,100,2)]
    if model == '2D':
        P = [i/100 for i in range(0,120,2)]
        
    with open('experiment1_rawData_' + model +'.csv','w') as file:
        file.write('r,p,z,k,jr,avApp')
        file.write('\n')
        file.close()
    for r in R:
        for p in tqdm(P):
            for z in range(1000):

                #Step1 - create elections
                if model == 'IC':
                    election = EqualChooseDistribution(p).generate(range(m),n)
                if model == '1D':
                    election = OneDDistribution(p).generate(range(m),n)
                if model == '2D':
                    election = TwoDDistribution(p).generate(range(m),n)

                #Step2 - Sample committee of size r
                W = random.sample(range(m),r)
                
                #Step3 - Check whether committee satisfies JR and compute average number of approvals
                jr = isJR(election,W,m,k)
                avApp = np.mean([len(election[v]) for v in range(n)])
                
                #Step 4 - Write Data into csv file
                with open('experiment1_rawData_'+ model +'.csv','a') as file:
                    file.write(str(r)+','+str(p)+','+str(z)+','+str(k)+','+str(jr)+','+str(avApp)+'\n')
                    file.close()
                
    
########### Plot results for the IC Model ######################
    
#Read Data from csv file
experiment_IC = 'experiment1_rawData_IC'
raw_data = pd.read_csv(experiment_IC + '.csv',index_col=[0,1])
agg = raw_data.groupby(['r','p'])[['jr','avApp']].mean()
R = list(set([i for (i,j) in agg.index]))
P = list(set([j for (i,j) in agg.index]))

#Create plot
fig = plt.figure(figsize=(12,8), dpi= 300)
ax = fig.add_subplot(111)
    
my_colors = dict({1.0:'tab:blue',2.0:'tab:orange',3.0:'tab:green',4.0:'tab:red'})
order_list = dict({1.0: 2,2.0:3,3.0:4,4.0:1})
    
for r in R:
    plt.plot(agg.loc[(r,)]['avApp'],agg.loc[(r,)]['jr'],linewidth=3.0,color=my_colors[r], zorder = order_list[r])
    #compute area in which Theorem 3.1 predicts fraction of jr committees to be zero
    P2 = [i/100 for i in range(0,100,2)]
    pred_zero =[p for p in P2 if p*((1-p)**r) > 1/k]
    if len(pred_zero) > 0:
        break_points = [min(pred_zero)*100,max(pred_zero)*100]
        plt.vlines(break_points,ymin=0,ymax=1,linestyles='dashed',color=my_colors[r])
       
ax.yaxis.label.set_size(28)
ax.xaxis.label.set_size(28)
ax.tick_params(axis='both', which='major', labelsize=24)
plt.ylabel(r'fraction of justifying groups',labelpad=30)
plt.xlabel(r'average number of approvals',labelpad=30)
ax.legend(['s = ' + str(int(r)) for r in R],loc=(0.615,0.4), fontsize=26)

plt.savefig(experiment_IC  + '.png',bbox_inches='tight')


########### Plot results for 1D and 2D Euclidean Model ##########################

for data in ['experiment1_rawData_1D','experiment1_rawData_2D']:
    #Read csv files
    raw_data = pd.read_csv(data + '.csv',index_col=[0,1])
    agg = raw_data.groupby(['r','p'])[['jr','avApp']].mean()
    R = list(set([i for (i,j) in agg.index]))
    P = list(set([j for (i,j) in agg.index]))

    fig = plt.figure(figsize=(12,8), dpi= 300)
    ax = fig.add_subplot(111)

    pattern_dict = dict({1:'dotted',2:'dashdot',3:'dashed',4:'solid'})

    for r in R:
        plt.plot(agg.loc[(r,)]['avApp'],agg.loc[(r,)]['jr'],linewidth=3.0,linestyle=pattern_dict[r])

    ax.yaxis.label.set_size(28)
    ax.xaxis.label.set_size(28)
    ax.tick_params(axis='both', which='major', labelsize=24)
    plt.ylabel(r'fraction of justifying groups',labelpad=30)
    plt.xlabel(r'average number of approvals',labelpad=30)

    ax.legend(['s = ' + str(int(r)) for r in R],loc=(0.15,0.58), fontsize=28)

    plt.savefig(data + '.png',bbox_inches='tight')




    
